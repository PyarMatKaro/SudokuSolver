﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace Sudoku
{
    public abstract class Hint
    {
        public abstract override string ToString();
        public abstract ExactCover.SolveResult Apply(SudokuGrid grid);
        public abstract bool AppliesAt(int x, int y, int b);

        public virtual void PaintBackground(PaintContext context) { }
        public virtual void PaintForeground(PaintContext context) { }
    }

    public class ImpossibleHint : Hint
    {
        ExactCover.Requirement c;

        public ImpossibleHint(ExactCover.Requirement c)
        {
            this.c = c;
        }

        public ExactCover.Requirement Requirement { get { return c; } }

        public override bool AppliesAt(int x, int y, int b)
        {
            return c.AppliesAt(x, y, b);
        }

        public override string ToString()
        {
            return "No solution, " + c.RequirementString(0);
        }

        public override ExactCover.SolveResult Apply(SudokuGrid grid)
        {
            return ExactCover.SolveResult.NoSolutions;
        }
    
        public override void PaintBackground(PaintContext context)
        {
            context.FillHouse(Brushes.Pink, Requirement);
        }

        public override void PaintForeground(PaintContext context)
        {
            if (c.house == ExactCover.Requirement.Houses.Column)
            {
                for (int y = 0; y < 9; ++y)
                    if (context.grid.FlagAt(c.i0, y) == SudokuGrid.CellFlags.Free)
                        context.DrawSubcell(Brushes.Red, c.i0, y, c.i1);
            }
            else if (c.house == ExactCover.Requirement.Houses.Row)
            {
                for (int x = 0; x < 9; ++x)
                    if (context.grid.FlagAt(x, c.i0) == SudokuGrid.CellFlags.Free)
                        context.DrawSubcell(Brushes.Red, x, c.i0, c.i1);
            }
            else if (c.house == ExactCover.Requirement.Houses.Box)
            {
                for (int x = 0; x < 9; ++x)
                    for (int y = 0; y < 9; ++y)
                        if (context.grid.FlagAt(x, y) == SudokuGrid.CellFlags.Free &&
                            context.grid.BoxAt(x, y) == c.i0)
                            context.DrawSubcell(Brushes.Red, x, y, c.i1);
            }
            else if (c.house == ExactCover.Requirement.Houses.MajorDiagonal)
            {
                for (int x = 0; x < 9; ++x)
                    if (context.grid.FlagAt(x, x) == SudokuGrid.CellFlags.Free)
                        context.DrawSubcell(Brushes.Red, x, x, c.i0);
            }
            else if (c.house == ExactCover.Requirement.Houses.MinorDiagonal)
                for (int x = 0; x < 9; ++x)
                    if (context.grid.FlagAt(x, 8-x) == SudokuGrid.CellFlags.Free)
                        context.DrawSubcell(Brushes.Red, x, 8-x, c.i0);
        }
    }

    public class ForcedMoveHint : Hint
    {
        ExactCover.Requirement c;
        ExactCover.Tile r;

        public ForcedMoveHint(ExactCover.Requirement c, ExactCover.Tile r)
        {
            this.c = c;
            this.r = r;
        }

        public ExactCover.Requirement Requirement { get { return c; } }
        public ExactCover.Tile Candidate { get { return r; } }

        public override bool AppliesAt(int x, int y, int b)
        {
            return c.AppliesAt(x, y, b);
        }

        public override string ToString()
        {
            return "Must " + r.CandidateString() + ", since " + c.RequirementString(1);
        }

        public override ExactCover.SolveResult Apply(SudokuGrid grid)
        {
            grid.SelectCandidate(r);
            return ExactCover.SolveResult.Ongoing;
        }

        public override void PaintBackground(PaintContext context)
        {
            context.FillHouse(Brushes.LightGreen, Requirement);
            int x, y, n;
            Candidate.GetCandidateInfo(out x, out y, out n);
            context.FillCell(x, y, Brushes.Green);
        }

        public override void PaintForeground(PaintContext context)
        {
            int x, y, n;
            r.GetCandidateInfo(out x, out y, out n);
            context.DrawSubcell(Brushes.White, x, y, n);
        }

    }

    public class DiscardableHint : Hint
    {
        ExactCover.Tile r;
        ExactCover.Requirement c;
        bool eventual;

        public DiscardableHint(ExactCover.Tile r, ExactCover.Requirement c, bool eventual)
        {
            this.r = r;
            this.c = c;
            this.eventual = eventual;
        }

        public override bool AppliesAt(int _x, int _y, int b)
        {
            int x, y, n;
            r.GetCandidateInfo(out x, out y, out n);
            return _x == x && _y == y;
        }

        public override string ToString()
        {
            return "Cannot " + r.CandidateString() + ", selection " +
                (eventual ? "eventually " : "") + "leads to " + c.RequirementString(0);
        }

        public override ExactCover.SolveResult Apply(SudokuGrid grid)
        {
            grid.DiscardCandidate(r);
            return ExactCover.SolveResult.Ongoing;
        }

        public override void PaintForeground(PaintContext context)
        {
            int x, y, n;
            r.GetCandidateInfo(out x, out y, out n);
            context.DrawSubcell(Brushes.Red, x, y, n);
        }

    }

    public class SelectableHint : Hint
    {
        ExactCover.Tile r;
        ExactCover.Requirement c;

        public SelectableHint(ExactCover.Tile r, ExactCover.Requirement c)
        {
            this.r = r;
            this.c = c;
        }

        public override bool AppliesAt(int _x, int _y, int b)
        {
            int x, y, n;
            r.GetCandidateInfo(out x, out y, out n);
            return _x == x && _y == y;
        }

        public override string ToString()
        {
            return "Must " + r.CandidateString() + ", discarding eventually leads to " + c.RequirementString(0);
        }

        public override ExactCover.SolveResult Apply(SudokuGrid grid)
        {
            grid.SelectCandidate(r);
            return ExactCover.SolveResult.Ongoing;
        }

        public override void PaintForeground(PaintContext context)
        {
            int x, y, n;
            r.GetCandidateInfo(out x, out y, out n);
            context.DrawSubcell(Brushes.Green, x, y, n);
        }

    }

    public class EventualSolutionHint : Hint
    {
        ExactCover.Tile r;

        public EventualSolutionHint(ExactCover.Tile r)
        {
            this.r = r;
        }

        public override bool AppliesAt(int _x, int _y, int b)
        {
            int x, y, n;
            r.GetCandidateInfo(out x, out y, out n);
            return _x == x && _y == y;
        }

        public override string ToString()
        {
            return "Should " + r.CandidateString() + ", assuming there is a single solution";
        }

        public override void PaintForeground(PaintContext context)
        {
            int x, y, n;
            r.GetCandidateInfo(out x, out y, out n);
            context.DrawSubcell(Brushes.Green, x, y, n);
        }

        public override ExactCover.SolveResult Apply(SudokuGrid grid)
        {
            grid.SelectCandidate(r);
            return ExactCover.SolveResult.Ongoing;
        }

    }
}
