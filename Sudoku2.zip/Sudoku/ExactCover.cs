﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sudoku
{
    public abstract class ExactCover
    {
        public enum SolveResult { NoSolutions, SingleSolution, MultipleSolutions, Ongoing, TooDifficult };
        bool verbose = false;

        protected Requirement[] ca;
        protected Tile[] tr;
        protected int trc;
        protected Tile[] ts;
        protected int tsc;

        protected Requirement h = new Requirement();

        protected void CreateRequirements(int nc)
        {
            ca = new Requirement[nc];
            for (int i = 0; i < ca.Length; ++i)
                ca[i] = new Requirement();
        }

        protected void CreateCandidates(int nr)
        {
            tr = new Tile[nr];
            trc = 0;
        }

        protected void CreateSolution(int nsr)
        {
            ts = new Tile[nsr];
            tsc = 0;
        }

        public class Tile
        {
            internal Tile l, r, u, d;
            internal Requirement c;
            internal bool included = false;
            private bool marked = false;

            public virtual bool AppliesAt(int x, int y, int b)
            {
                return false;
            }

            internal void MarkCandidate(bool mark)
            {
                for (Tile j = r; j != this; j = j.r)
                    j.marked = mark;
                marked = mark;
            }

            public bool IsMarked { get { return marked; } }

            void CheckIncluded()
            {
                System.Diagnostics.Debug.Assert(l.r == this);
                System.Diagnostics.Debug.Assert(r.l == this);
                System.Diagnostics.Debug.Assert(u.d == this);
                System.Diagnostics.Debug.Assert(d.u == this);
            }

            public bool Included
            {
                get
                {
                    if (included)
                        CheckIncluded();
                    return included;
                }
            }

            internal void ExcludeH()
            {
                r.l = l;
                l.r = r;
                included = false;
            }

            internal void IncludeH()
            {
                r.l = this;
                l.r = this;
                included = true;
                CheckIncluded();
            }

            internal void ExcludeV()
            {
                d.u = u;
                u.d = d;
                c.s--;
                included = false;
            }

            internal void IncludeV()
            {
                included = true;
                c.s++;
                d.u = this;
                u.d = this;
                CheckIncluded();
            }

            public Tile()
            {
                ClearTile();
            }

            public static Tile AddToCandidate(Tile x, Requirement c)
            {
                Tile t = new Tile();
                t.ClearTile();
                if (x != null)
                {
                    x.r.l = t;
                    t.r = x.r;
                    x.r = t;
                    t.l = x;
                }
                t.c = c;
                c.s++;
                t.d = c.d;
                c.d.u = t;
                c.d = t;
                t.u = c;
                t.included = true;
                return t;
            }

            protected void ClearTile()
            {
                l = r = u = d = this;
                c = null;
                included = false;
            }

            internal int CandidateOptions
            {
                get
                {
                    int o = c.s;
                    Tile j = this;
                    do
                    {
                        if (j.c.s < o)
                            o = j.c.s;
                        j = j.r;
                    }
                    while (j != this);
                    return o;
                }
            }

            internal void GetCandidateInfo(out int x, out int y, out int n)
            {
                x = y = n = -1;
                Tile j = this;
                do
                {
                    Requirement c = j.c;
                    if (c.house == Requirement.Houses.Cell)
                    {
                        x = c.i0;
                        y = c.i1;
                    }
                    else if (c.house == Requirement.Houses.Column)
                    {
                        x = c.i0;
                        n = c.i1;
                    }
                    j = j.r;
                } while (j != this);
            }

            public string CandidateString()
            {
                int x, y, n;
                GetCandidateInfo(out x, out y, out n);
                return "fill " + (1 + x) + "," + (1 + y) + " with " + (1 + n);
            }

            public override string ToString()
            {
                return CandidateString();
            }
        }

        public class Requirement : Tile
        {
            public enum Houses { Cell, Column, Row, Box, MajorDiagonal, MinorDiagonal };
            public Houses house;
            public int s, i0, i1;

            public Requirement()
            {
                ClearRequirement();
            }

            public override bool AppliesAt(int x, int y, int b)
            {
                if (house == Houses.Cell)
                    return x == i0 && y == i1;
                if (house == Houses.Column)
                    return x == i0;
                if (house == Houses.Row)
                    return y == i0;
                if (house == Houses.Box)
                    return b == i0;
                if (house == Houses.MajorDiagonal)
                    return x == y && x == i0;
                if (house == Houses.MinorDiagonal)
                    return x == 9-y && x == i0;
                return false;
            }

            public Requirement Right
            {
                get
                {
                    return (Requirement)r;
                }
            }

            void ClearRequirement()
            {
                ClearTile();
                s = 0;
            }

            public void AddRequirement(Requirement c)
            {
                r.l = c;
                c.r = r;
                r = c;
                c.l = this;
                included = true;
            }

            public void Cover()
            {
                ExcludeH();
                for (Tile i = d; i != this; i = i.d)
                    for (Tile j = i.r; j != i; j = j.r)
                        j.ExcludeV();
            }

            public void Uncover()
            {
                for (Tile i = u; i != this; i = i.u)
                    for (Tile j = i.l; j != i; j = j.l)
                        j.IncludeV();
                IncludeH();
            }

            public string RequirementString(int s)
            {
                string ret;
                if (s == 0)
                    ret = "no way to ";
                else if (s == 1)
                    ret = "only one way to ";
                else
                    ret = s + " ways to ";

                if (house == Houses.Cell)
                    ret += "fill cell at " + (1 + i0) + "," + (1 + i1);
                else if (house == Houses.Column)
                    ret += "place " + (1 + i1) + " in column " + (1 + i0);
                else if (house == Houses.Row)
                    ret += "place " + (1 + i1) + " in row " + (1 + i0);
                else if (house == Houses.Box)
                    ret += "place " + (1 + i1) + " in box " + (1 + i0);
                else if (house == Houses.MajorDiagonal)
                    ret += "place " + (1 + i0) + " in major diagonal";
                else if (house == Houses.MinorDiagonal)
                    ret += "place " + (1 + i0) + " in minor diagonal";
                
                return ret;
            }

            public override string ToString()
            {
                return RequirementString(s);
            }

            public Tile[] UnselectedCandidates
            {
                get
                {
                    Tile[] ret = new Tile[s];
                    int j = 0;
                    for (Tile i = u; i != this; i = i.u)
                        ret[j++] = i;
                    return ret;
                }
            }

        };

        protected void CoverCandidate(Tile r)
        {
            ts[tsc++] = r;
            for (Tile j = r.r; j != r; j = j.r)
                j.c.Cover();
        }

        protected void UncoverCandidate()
        {
            Tile r = ts[--tsc];
            for (Tile j = r.l; j != r; j = j.l)
                j.c.Uncover();
        }

        public bool Solved { get { return h.Right == h; } }

        public Requirement EasiestRequirement
        {
            get
            {
                Requirement c = h.Right;
                Requirement bc = null;
                while (c != h)
                {
                    if (bc == null || c.s <= bc.s)
                        bc = c;
                    c = c.Right;
                }
                return bc;
            }
        }

        public Requirement FollowSingleOptions()
        {
            while (true)
            {
                if (Solved)
                    return null;
                Requirement c = EasiestRequirement;
                if (c.s != 1)
                    return c;
                SelectCandidate(c.d);
            }
        }

        public void CheckSelectCandidate(Tile t, out Requirement c, out int o)
        {
            int sc = tsc;
            SelectCandidate(t);
            c = EasiestRequirement;
            o = 1;
            if (c != null)
                o = c.s;
            while (tsc > sc)
                UnselectCandidate();
        }

        public void CheckSelectCandidateFollowingSingleOptions(Tile t, out Requirement c, out int o)
        {
            int sc = tsc;
            if (t != null)
                SelectCandidate(t);
            c = FollowSingleOptions();
            o = 1;
            if (c != null)
                o = c.s;
            while (tsc > sc)
                UnselectCandidate();
        }

        public void CheckDiscardCandidateFollowingSingleOptions(Tile t, out Requirement c, out int o)
        {
            if (t != null)
                DiscardCandidate(t);
            int sc = tsc;
            c = FollowSingleOptions();
            o = 1;
            if (c != null)
                o = c.s;
            while (tsc > sc)
                UnselectCandidate();
            UndiscardCandidate(t);
        }

        public abstract bool OnSolution();

        public bool BacktrackingSearch()
        {
            if (Solved)
                return OnSolution();

            Requirement c = EasiestRequirement;
            if (verbose)
                Console.WriteLine(c.ToString());
            int s = c.s;
            int i = 0;
            if (s == 0)
                return false;
            c.Cover();
            if (verbose && s != 1)
                Console.WriteLine("(start of loop)");
            bool brk = false;
            for (Tile r = c.d; r != c; r = r.d)
            {
                if (verbose && s != 1)
                    Console.WriteLine("(loop " + (++i) + "/" + s + ")");
                if (verbose)
                    Console.WriteLine(r.CandidateString());
                CoverCandidate(r);
                brk = BacktrackingSearch();
                UncoverCandidate();
                if (brk)
                    break;
            }
            c.Uncover();
            if (verbose && s != 1)
                Console.WriteLine("(end of loop)");
            return brk;
        }

        public Requirement[] UnfulfilledRequirements
        {
            get
            {
                int n = 0;
                for (Requirement c = h.Right; c != h; c = c.Right)
                    ++n;
                Requirement[] ret = new Requirement[n];
                for (Requirement c = h.Right; c != h; c = c.Right)
                    ret[--n] = c;
                return ret;
            }
        }

        public Tile[] UnselectedCandidates
        {
            get
            {
                List<Tile> ret = new List<Tile>();
                foreach (Requirement c in UnfulfilledRequirements)
                    foreach (Tile t in c.UnselectedCandidates)
                        if(!t.IsMarked)
                        {
                            t.MarkCandidate(true);
                            ret.Add(t);
                        }
                foreach (Tile t in ret)
                    t.MarkCandidate(false);
                return ret.ToArray();
            }
        }

        public Tile[] SelectedCandidates
        {
            get
            {
                Tile[] ret = new Tile[tsc];
                for (int n = 0; n < tsc; ++n)
                    ret[n] = ts[n];
                return ret;
            }
        }

        public void SelectCandidate(Tile r)
        {
            r.c.Cover();
            CoverCandidate(r);
        }

        public void UnselectCandidate()
        {
            Tile r = ts[tsc-1];
            UncoverCandidate();
            r.c.Uncover();
        }

        public bool TrySelectCandidate(Tile r)
        {
            // Check that candidate is unselected
            if (!UnfulfilledRequirements.Contains(r.c))
                return false;
            if (!r.c.UnselectedCandidates.Contains(r))
                return false;
            SelectCandidate(r);
            return true;
        }

        public void DiscardCandidate(Tile t)
        {
            t.ExcludeV();
            for (Tile j = t.r; j != t; j = j.r)
                j.ExcludeV();
        }

        public void UndiscardCandidate(Tile t)
        {
            for (Tile j = t.l; j != t; j = j.l)
                j.IncludeV();
            t.IncludeV();
        }

        #region hints

        public Hint[] HintsToPaint(HintFlags ho, HintSelections hs)
        {
            List<Hint> ret = new List<Hint>();
            Requirement c = EasiestRequirement;
            if (c != null)
            {
                if (c.s == 0)
                    return new Hint[] { new ImpossibleHint(c) };
                if (c.s == 1 && hs.ForcedMoves)
                    return new Hint[] { new ForcedMoveHint(c, c.d) };
                    //ret.Add( new ForcedMoveHint(c, c.d) );
            }
            Tile[] uc = UnselectedCandidates;
            DiscardableHint[] eventualDiscardableHints;
            EventualSolutionHint[] eventualSolutionHints;
            SelectableHint[] selectableHints;
            BuildEventualHints(out eventualDiscardableHints, out eventualSolutionHints,
                out selectableHints);
            if (hs.EventualDiscardables)
                ret.AddRange(eventualDiscardableHints);
            else if (hs.ImmediateDiscardables)
                ret.AddRange(ImmediateDiscardableHints);
            if (hs.EventualSolutions)
                ret.AddRange(eventualSolutionHints);
            if (hs.Selectables)
                ret.AddRange(selectableHints);
            return ret.ToArray();
        }

        public ImpossibleHint SingleImpossibleHint
        {
            get
            {
                Requirement c = EasiestRequirement;
                if (c != null)
                    if (c.s == 0)
                        return new ImpossibleHint(c);
                return null;
            }
        }

        public ForcedMoveHint SingleForcedHint
        {
            get
            {
                Requirement c = EasiestRequirement;
                if (c != null)
                    if (c.s == 1)
                        return new ForcedMoveHint(c, c.d);
                return null;
            }
        }

        public Requirement[] RestrictedRequirements(Tile t, int s)
        {
            int n = 0;
            for (Tile i = t.r; i != t; i = i.r)
                if (i.c.s == s)
                    ++n;
            if (t.c.s == s)
                ++n;
            Requirement[] ret = new Requirement[n];
            for (Tile i = t.r; i != t; i = i.r)
                if (i.c.s == s)
                    ret[--n] = i.c;
            if (t.c.s == s)
                ret[--n] = t.c;
            return ret;
        }

        public Hint SingleHint(HintSelections hs)
        {
            Requirement c = EasiestRequirement;
            if (c != null)
            {
                if (c.s == 0)
                    return new ImpossibleHint(c);
                if (c.s == 1 && hs.ForcedMoves)
                    return new ForcedMoveHint(c, c.d);
            }

            Tile[] uc = UnselectedCandidates;
            if(hs.ImmediateDiscardables)
                foreach (Tile t in uc)
                {
                    int o;
                    CheckSelectCandidate(t, out c, out o);
                    if (o == 0)
                        return new DiscardableHint(t, c, false);
                }
            foreach (Tile t in uc)
            {
                int o;
                CheckSelectCandidateFollowingSingleOptions(t, out c, out o);
                if (hs.EventualDiscardables && o == 0)
                    return new DiscardableHint(t, c, true);
                if (hs.EventualSolutions && o == 1)
                    return new EventualSolutionHint(t);
                if (hs.Selectables)
                {
                    CheckDiscardCandidateFollowingSingleOptions(t, out c, out o);
                    if (o == 0)
                        return new SelectableHint(t, c);
                }
            }
            return null;
        }

        public DiscardableHint[] ImmediateDiscardableHints
        {
            get
            {
                List<DiscardableHint> ret = new List<DiscardableHint>();
                foreach (Tile t in UnselectedCandidates)
                {
                    Requirement c;
                    int o;
                    CheckSelectCandidate(t, out c, out o);
                    if (o == 0)
                        ret.Add(new DiscardableHint(t, c, false));
                }
                return ret.ToArray();
            }
        }

        public void BuildEventualHints(
            out DiscardableHint[] eventualDiscardableHints,
            out EventualSolutionHint[] eventualSolutionHints,
            out SelectableHint[] selectableHints)
        {
            List<DiscardableHint> ret0 = new List<DiscardableHint>();
            List<EventualSolutionHint> ret1 = new List<EventualSolutionHint>();
            List<SelectableHint> ret2 = new List<SelectableHint>();
            foreach (Tile t in UnselectedCandidates)
            {
                Requirement c;
                int o;
                CheckSelectCandidateFollowingSingleOptions(t, out c, out o);
                if (o == 0)
                    ret0.Add(new DiscardableHint(t, c, true));
                if (o == 1)
                    ret1.Add(new EventualSolutionHint(t));
                CheckDiscardCandidateFollowingSingleOptions(t, out c, out o);
                if (o == 0)
                    ret2.Add(new SelectableHint(t, c));
            }
            eventualDiscardableHints = ret0.ToArray();
            eventualSolutionHints = ret1.ToArray();
            selectableHints = ret2.ToArray();
        }

        public ImpossibleHint[] ImpossibleHints
        {
            get
            {
                int n = 0;
                for (Requirement c = h.Right; c != h; c = c.Right)
                    if (c.s < 1)
                        ++n;
                ImpossibleHint[] ret = new ImpossibleHint[n];
                for (Requirement c = h.Right; c != h; c = c.Right)
                    if (c.s < 1)
                        ret[--n] = new ImpossibleHint(c);
                return ret;
            }
        }

        public ForcedMoveHint[] ForcedHints
        {
            get
            {
                int n = 0;
                for (Requirement c = h.Right; c != h; c = c.Right)
                    if (c.s == 1)
                        ++n;
                ForcedMoveHint[] ret = new ForcedMoveHint[n];
                for (Requirement c = h.Right; c != h; c = c.Right)
                    if (c.s == 1)
                        ret[--n] = new ForcedMoveHint(c, c.d);
                return ret;
            }
        }

        #endregion

    }
}
