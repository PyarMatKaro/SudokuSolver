﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sudoku
{
    public class SudokuSolver : ExactCover
    {
        private int solnsFound;
        private Tile[] sampleSoln;

        public SudokuSolver(SudokuGrid grid)
        {
            CreateMatrix(grid);
            for (int x = 0; x < 9; ++x)
                for (int y = 0; y < 9; ++y)
                    if (grid.FlagAt(x, y) != SudokuGrid.CellFlags.Free)
                        TrySelectCandidate(GetCandidate(x, y, grid.ValueAt(x, y)));
        }

        public SolveResult DoLogicalSolve(SudokuGrid grid, HintSelections hs)
        {
            while (true)
            {
                if (Solved)
                    return SolveResult.SingleSolution;
                Hint hint = SingleHint(hs);
                if (hint == null)
                    return SolveResult.TooDifficult;
                SolveResult result = hint.Apply(grid);
                if(result != SolveResult.Ongoing)
                    return result;
            }
        }

        public SolveResult DoBacktrackingSolve()
        {
            //verbose = false;
            solnsFound = 0;
            int osc = tsc;
            BacktrackingSearch();
            if (solnsFound == 0)
                return SolveResult.NoSolutions;
            if (solnsFound == 1)
            {
                for (int i = osc; i < sampleSoln.Length; ++i)
                    SelectCandidate(sampleSoln[i]);
                return SolveResult.SingleSolution;
            }
            return SolveResult.MultipleSolutions;
        }

        public override bool OnSolution()
        {
            //Console.WriteLine("Solution");
            //Console.WriteLine(GridString());
            ++solnsFound;
            if (solnsFound > 1)
                return true;
            sampleSoln = SelectedCandidates;
            return false;
        }

        public Requirement GetRequirement(int x, int y, int type)
        {
            return ca[x + y * 9 + type * 9 * 9];
        }

        Requirement GetMajorDiagonalRequirement(int n)
        {
            return ca[ 9 * 9 * 4 + n];
        }

        Requirement GetMinorDiagonalRequirement(int n)
        {
            return ca[ 9 * 9 * 4 + 9 + n];
        }

        /*
        public SudokuSolver(string[] lines)
        {
            CreateMatrix();
            Apply(lines);
        }
        */

        void CreateMatrix(SudokuGrid grid)
        {
            bool diagonal = grid.HasDiagonals;
            // Create requirements - columns of 0/1 matrix
            CreateRequirements(9 * 9 * 4 + 2 * 9);
            ExactCover.Requirement.Houses[] houses = new Requirement.Houses[]{
                ExactCover.Requirement.Houses.Cell,
                ExactCover.Requirement.Houses.Column,
                ExactCover.Requirement.Houses.Row,
                ExactCover.Requirement.Houses.Box};
            for (int i0 = 0; i0 < 9; ++i0)
            {
                for (int i1 = 0; i1 < 9; ++i1)
                {
                    for (int type = 0; type < 4; ++type)
                    {
                        ExactCover.Requirement.Houses house = houses[type];
                        Requirement c = GetRequirement(i0, i1, type);
                        c.i0 = i0;
                        c.i1 = i1;
                        c.house = house;
                        h.AddRequirement(c);
                    }
                }
            }
            if (diagonal)
            {
                for (int i0 = 0; i0 < 9; ++i0)
                {
                    Requirement c = GetMajorDiagonalRequirement(i0);
                    c.i0 = i0;
                    c.i1 = -1;
                    c.house = Requirement.Houses.MajorDiagonal;
                    h.AddRequirement(c);

                    c = GetMinorDiagonalRequirement(i0);
                    c.i0 = i0;
                    c.i1 = -1;
                    c.house = Requirement.Houses.MinorDiagonal;
                    h.AddRequirement(c);
                }
            }
            
            // Create candidates - rows of 0/1 matrix
            CreateCandidates(9 * 9 * 9);
            CreateSolution(9 * 9);
            for (int x = 0; x < 9; ++x)
            {
                for (int y = 0; y < 9; ++y)
                {
                    int b = grid.BoxAt(x, y);
                    for (int n = 0; n < 9; ++n)
                    {
                        Tile lt = null;
                        lt = Tile.AddToCandidate(lt, GetRequirement(x, y, 0));
                        lt = Tile.AddToCandidate(lt, GetRequirement(x, n, 1));
                        lt = Tile.AddToCandidate(lt, GetRequirement(y, n, 2));
                        lt = Tile.AddToCandidate(lt, GetRequirement(b, n, 3));
                        if (diagonal)
                        {
                            if (x == y)
                                lt = Tile.AddToCandidate(lt, GetMajorDiagonalRequirement(n));
                            if (x == 8 - y)
                                lt = Tile.AddToCandidate(lt, GetMinorDiagonalRequirement(n));
                        }
                        tr[trc++] = lt;
                    }
                }
            }
        }

        public Tile GetCandidate(int x, int y, int n)
        {
            return tr[n + y * 9 + x * 9 * 9];
        }

        public string[] SolutionStrings()
        {
            string[] ret = new string[9];
            char[,] g = new char[9, 9];
            for (int x = 0; x < 9; ++x)
                for (int y = 0; y < 9; ++y)
                    g[x, y] = '.';
            for (int i = 0; i < tsc; ++i)
            {
                int x, y, n;
                ts[i].GetCandidateInfo(out x, out y, out n);
                g[x, y] = (char)('1' + n);
            }
            for (int y = 0; y < 9; ++y)
            {
                ret[y] = "";
                for (int x = 0; x < 9; ++x)
                    if (g[x, y] == '.')
                    {
                        ret[y]+="[";
                        Requirement c = GetRequirement(x, y, 0);
                        for(Tile t=c.u; t!=c; t=t.u)
                        {
                            int x2,y2,n;
                            t.GetCandidateInfo(out x2,out y2,out n);
                            ret[y] += (char)('1' + n);
                        }
                        ret[y] += "]";
                    }
                    else
                        ret[y] += g[x, y];
            }
            return ret;
        }

        public Tile[] RandomSolution()
        {
            if (SolveRandomly() == SolveResult.SingleSolution)
                return sampleSoln;
            return null;
        }

        SolveResult SolveRandomly()
        {
            if (Solved)
            {
                sampleSoln = SelectedCandidates;
                return SolveResult.SingleSolution;
            }
            Requirement c = EasiestRequirement;
            if (c.s == 0)
                return SolveResult.NoSolutions;

            List<Tile> list = new List<Tile>();
            list.AddRange(c.UnselectedCandidates);
            while (list.Count > 0)
            {
                int i = Utils.Rnd(list.Count);
                Tile t = list[i];
                list.RemoveAt(i);
                SelectCandidate(t);
                SolveResult sr = SolveRandomly();
                UnselectCandidate();
                if (sr == SolveResult.SingleSolution)
                    return SolveResult.SingleSolution;
            }
            return SolveResult.NoSolutions;
        }

    }
}
