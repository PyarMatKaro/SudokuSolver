﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;

namespace Sudoku
{
    public class SudokuGrid
    {
        public enum CellFlags { Free, Fixed, Play };
        CellFlags[,] flags;
        //public const int FREE = 0;
        //public const int FIXED = 1;
        //public const int PLAY = 2;

        public enum PlayModes { Edit, Play, Pencil };
        public PlayModes PlayMode;

        bool requestedHint;
        List<UpdateListener> listeners = new List<UpdateListener>();
        int[,] values, boxes;
        SudokuSolver solver;
        bool diagonal;
        HintOptions hintOptions = new HintOptions();
        Hint[] paintedHints = new Hint[0];

        public SudokuGrid(bool diagonal)
        {
            ClearGrid(diagonal);
        }

        public void RequestHint()
        {
            requestedHint = true;
            UpdatePaintedHints();
        }

        public Hint[] PaintedHints { get { return paintedHints; } }
        public HintOptions HintOptions { get { return hintOptions; } set { hintOptions = value; } }
        public HintFlags HintFlags { get { return hintOptions.Flags; } set { hintOptions.Flags = value; } }
        public HintSelections HintShow { get { return hintOptions.Show; } set { hintOptions.Show = value; } }
        public HintSelections HintAutoSolve { get { return hintOptions.AutoSolve; } set { hintOptions.AutoSolve = value; } }

        public bool HasDiagonals { get { return diagonal; } }

        public static void ReplaceListener(UpdateListener listener, SudokuGrid value, ref SudokuGrid grid)
        {
            if (grid == value)
                return;
            if (grid != null)
                grid.RemoveListener(listener);
            grid = value;
            if (grid != null)
                grid.AddListener(listener);
        }

        public void ClearGrid()
        {
            ClearGrid(diagonal);
        }

        public static int DefaultBoxAt(int x, int y)
        {
            return (x / 3) + (y / 3) * 3;
        }

        public int BoxAt(int x, int y)
        {
            return boxes[x, y];
        }

        public CellFlags FlagAt(int x, int y)
        {
            return flags[x, y];
        }

        public int ValueAt(int x, int y)
        {
            return values[x, y];
        }

        public void ClearGrid(bool diagonal)
        {
            this.diagonal = diagonal;
            values = new int[9, 9];
            flags = new CellFlags[9, 9];
            boxes = new int[9, 9];
            for (int x = 0; x < 9; ++x)
                for (int y = 0; y < 9; ++y)
                {
                    values[x, y] = -1;
                    flags[x, y] = CellFlags.Free;
                    boxes[x, y] = DefaultBoxAt(x, y);
                }
            solver = new SudokuSolver(this);
        }

        public bool IsJigsaw
        {
            get
            {
                for (int x = 0; x < 9; ++x)
                    for (int y = 0; y < 9; ++y)
                        if (boxes[x, y] != DefaultBoxAt(x, y))
                            return true;
                return false;
            }
        }

        public void AddListener(UpdateListener listener)
        {
            listeners.Add(listener);
        }

        public void RemoveListener(UpdateListener listener)
        {
            listeners.Remove(listener);
        }

        public void NotifyListeners(Action<UpdateListener> f)
        {
            foreach (UpdateListener listener in listeners)
                f(listener);
        }

        public void Paint(PaintContext context)
        {
            Graphics graphics = context.graphics;

            // Background
            Brush back = (solver.UnfulfilledRequirements.Length == 0)
                ? Brushes.LightGreen : Brushes.White;
            context.FillBackground(back);

            // Diagonals
            if (diagonal)
            {
                for (int x = 0; x < 9; ++x)
                {
                    context.FillCell(x, x, Brushes.LightGray);
                    if (x != 8 - x)
                        context.FillCell(x, 8 - x, Brushes.LightGray);
                }
            }

            foreach (Hint hint in paintedHints)
                hint.PaintBackground(context);

            context.DrawSelection();

            // Grid
            using (Pen thick = new Pen(Color.Black, 3.0f))
            {
                for (int x = 0; x < 8; ++x)
                    for (int y = 0; y < 9; ++y)
                    {
                        Pen p = BoxAt(x, y) == BoxAt(x + 1, y) ? Pens.Black : thick;
                        context.DrawVerticalLine(x, y, p);
                    }
                for (int x = 0; x < 9; ++x)
                    for (int y = 0; y < 8; ++y)
                    {
                        Pen p = BoxAt(x, y) == BoxAt(x, y + 1) ? Pens.Black : thick;
                        context.DrawHorizontalLine(x, y, p);
                    }
            }

            // Givens
            {
                for (int x = 0; x < 9; ++x)
                    for (int y = 0; y < 9; ++y)
                        if (flags[x, y] == CellFlags.Fixed)
                            context.DrawCell(Brushes.Black, x, y, values[x, y]);
                        else if (flags[x, y] == CellFlags.Play)
                            context.DrawCell(Brushes.Purple, x, y, values[x, y]);
            }

            // Knowns of solver
            {
                foreach (ExactCover.Tile r in solver.SelectedCandidates)
                {
                    int x, y, n;
                    r.GetCandidateInfo(out x, out y, out n);
                    if (flags[x, y] == CellFlags.Free)
                        context.DrawCell(Brushes.Green, x, y, n);
                }
            }

            // Unknowns as pencil marks
            if (HintFlags.PaintPencilMarks)
            {
                foreach (ExactCover.Tile r in solver.UnselectedCandidates)
                {
                    int x, y, n;
                    r.GetCandidateInfo(out x, out y, out n);
                    context.DrawSubcell(Brushes.Black, x, y, n);
                }
            }

            foreach (Hint hint in paintedHints)
                hint.PaintForeground(context);
        }

        void UpdatePaintedHints()
        {
            if (PlayMode == PlayModes.Edit)
            {
                Hint hint = solver.SingleImpossibleHint;
                if (hint != null)
                    paintedHints = new Hint[] { hint };
                else
                    paintedHints = new Hint[0];
            }
            else if (requestedHint || HintFlags.PaintHints)
            {
                //if (hintAutoSolve.ForcedHints)
                //    solver.FollowSingleOptions();
                solver.DoLogicalSolve(this, HintAutoSolve);
                paintedHints = solver.HintsToPaint(HintFlags, HintShow);
            }
            else
            {
                paintedHints = new Hint[0];
            }
            requestedHint = false;
        }

        public ForcedMoveHint SingleForcedHint { get { return solver.SingleForcedHint; } }

        public bool ClearCell(int x, int y)
        {
            if (flags[x, y] == CellFlags.Fixed && PlayMode != PlayModes.Edit)
                return false;
            if (flags[x, y] != CellFlags.Free)
            {
                flags[x, y] = CellFlags.Free;
                ResetSolver();
            }
            return true;
        }

        public bool SetCell(int x, int y, int n)
        {
            return SetCell(x, y, n, PlayMode);
        }

        public bool SetCell(int x, int y, int n, PlayModes playMode)
        {
            if (playMode == PlayModes.Pencil)
                return PencilCell(x, y, n);

            CellFlags fx = playMode == PlayModes.Edit ? CellFlags.Fixed : CellFlags.Play;
            if (flags[x, y] == CellFlags.Free)
                return SetFreeCell(x, y, n, fx);
            else
                return SetFilledCell(x, y, n, fx);
        }

        bool PencilCell(int x, int y, int n)
        {
            foreach (ExactCover.Tile t in solver.UnselectedCandidates)
            {
                int x2, y2, n2;
                t.GetCandidateInfo(out x2, out y2, out n2);
                if (x == x2 && y == y2 && n == n2)
                {
                    solver.DiscardCandidate(t);
                    Updated();
                    return true;
                }
            }
            return false;
        }

        bool SetFreeCell(int x, int y, int n, CellFlags fx)
        {
            // Agree with any existing known for that cell
            foreach (ExactCover.Tile t in solver.SelectedCandidates)
            {
                int x2, y2, n2;
                t.GetCandidateInfo(out x2, out y2, out n2);
                if (x == x2 && y == y2)
                {
                    if (n == n2)
                    {
                        flags[x, y] = fx;
                        values[x, y] = n;
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
            return AddClue(x, y, n, fx);
        }

        bool AddClue(int x, int y, int n, CellFlags fx)
        {
            ExactCover.Tile t = solver.GetCandidate(x, y, n);
            if (solver.TrySelectCandidate(t))
            {
                // Add clue
                flags[x, y] = fx;
                values[x, y] = n;
                Updated();
                return true;
            }
            else
            {
                // Clue cannot be added
                return false;
            }
        }

        bool SetFilledCell(int x, int y, int n, CellFlags fx)
        {
            if (flags[x, y] == CellFlags.Fixed && fx != CellFlags.Fixed)
            {
                // Don't play into fixed cell
                return values[x, y] == n;
            }
            flags[x, y] = fx;
            if (values[x, y] != n)
            {
                // Change clue, reset solver
                values[x, y] = n;
                ResetSolver();
            }
            return true;
        }

        internal void SelectCandidate(ExactCover.Tile r)
        {
            solver.SelectCandidate(r);
        }

        internal void DiscardCandidate(ExactCover.Tile r)
        {
            solver.DiscardCandidate(r);
        }

        internal void UndiscardCandidate(ExactCover.Tile r)
        {
            solver.UndiscardCandidate(r);
        }

        public void ResetSolver()
        {
            solver = new SudokuSolver(this);
            Updated();
        }

        public void Updated()
        {
            FireChanged();
            UpdatePaintedHints();
        }

        public void SolveLogically()
        {
            HintSelections.Level[] levels = new HintSelections.Level[]{
                HintSelections.Level.Easy,
                HintSelections.Level.Medium,
                HintSelections.Level.Hard,
                HintSelections.Level.Diabolical};
            foreach (HintSelections.Level level in levels)
            {
                HintSelections hs = new HintSelections(level);
                ExactCover.SolveResult solns = solver.DoLogicalSolve(this, hs);
                if (solns == ExactCover.SolveResult.SingleSolution)
                {
                    SolveLevel(level);
                    return;
                }
                else if (solns != ExactCover.SolveResult.TooDifficult)
                {
                    SolveResult(solns);
                    return;
                }
            }
            SolveResult(ExactCover.SolveResult.TooDifficult);
        }

        public void SolveBacktracking()
        {
            ExactCover.SolveResult solns = solver.DoBacktrackingSolve();
            SolveResult(solns);
        }

        public void SolveLevel(HintSelections.Level level)
        {
            Updated(); // Made some progress
            MessageBox.Show("Solution found, " + level, "Solve", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        public void SolveResult(ExactCover.SolveResult solns)
        {
            Updated(); // May have made some progress
            switch (solns)
            {
                case ExactCover.SolveResult.MultipleSolutions:
                    MessageBox.Show("Multiple solutions", "Solve", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
                case ExactCover.SolveResult.NoSolutions:
                    MessageBox.Show("No solutions", "Solve", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
                case ExactCover.SolveResult.Ongoing:
                    break;
                case ExactCover.SolveResult.SingleSolution:
                    MessageBox.Show("Single solution found", "Solve", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    break;
                case ExactCover.SolveResult.TooDifficult:
                    MessageBox.Show("Too difficult", "Solve", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    break;
            }
        }

        public void FireChanged()
        {
            NotifyListeners((UpdateListener listener) => listener.OnChangeGrid());
        }

        public string[] GridStringsCompact()
        {
            string[] s = new string[9];
            for (int y = 0; y < 9; ++y)
            {
                for (int x = 0; x < 9; ++x)
                    if (flags[x, y] == CellFlags.Fixed)
                        s[y] += (char)('1' + values[x, y]);
                    else
                        s[y] += ".";
            }
            return s;
        }

        public string[] GridStrings()
        {
            if (IsJigsaw)
                return GridStringsJigsaw;
            else
                return GridStringsNonJigsaw;
        }

        string[] GridStringsJigsaw
        {
            get
            {
                List<string> l = new List<string>();
                if (diagonal)
                    l.Add("DIAGONALS");
                for (int y = 0; y < 9; ++y)
                {
                    string s = "";
                    for (int x = 0; x < 9; ++x)
                    {
                        s += (char)('a' + boxes[x, y]);
                        if (flags[x, y] == CellFlags.Fixed)
                            s += (char)('1' + values[x, y]);
                        else
                            s += ".";
                    }
                    l.Add(s);
                }
                return l.ToArray();
            }
        }

        string[] GridStringsNonJigsaw
        {
            get
            {
                List<string> l = new List<string>();
                if (diagonal)
                    l.Add("DIAGONALS");
                for (int y = 0; y < 9; ++y)
                {
                    string s = " ";
                    for (int x = 0; x < 9; ++x)
                    {
                        if (flags[x, y] == CellFlags.Fixed)
                            s += (char)('1' + values[x, y]);
                        else
                            s += ".";
                        s += " ";
                        if (x == 2 || x == 5)
                            s += "| ";
                    }
                    l.Add(s);
                    if (y == 2 || y == 5)
                        l.Add("-------+-------+-------");
                }
                return l.ToArray();
            }
        }

        public string[] SolutionStrings
        {
            get
            {
                return solver.SolutionStrings();
            }
        }

        public void SetGridStrings(string[] a)
        {
            if (SetGridStrings9x9Jigsaw(a))
                return;
            if (SetGridStrings9x9(a))
                return;
            SetGridStrings81(a);
        }

        public bool SetGridStrings81(string[] a)
        {
            for (int i = 0; i < a.Length; ++i)
            {
                string s = a[i];
                if (s.Length == 81)
                {
                    ClearGrid(false);
                    for (int y = 0; y < 9; ++y)
                        for (int x = 0; x < 9; ++x)
                        {
                            char c = s[y * 9 + x];
                            if (c >= '1' && c <= '9')
                            {
                                values[x, y] = c - '1';
                                flags[x, y] = CellFlags.Fixed;
                            }
                        }
                    ResetSolver();
                    return true;
                }
            }
            return false;
        }

        public bool SetGridStrings9x9(string[] a)
        {
            bool diags = false;
            List<string> l = new List<string>();
            for (int y = 0; y < a.Length; ++y)
            {
                if (a[y].ToUpper().StartsWith("D"))
                    diags = true;
                else
                {
                    string s = "";
                    for (int x = 0; x < a[y].Length; ++x)
                    {
                        char c = a[y][x];
                        if (c == '.' || c >= '1' && c <= '9')
                            s += c;
                    }
                    if (s.Length == 9)
                        l.Add(s);
                }
            }
            a = l.ToArray();
            if (a.Length != 9)
                return false;
            ClearGrid(diags);
            for (int y = 0; y < 9; ++y)
                for (int x = 0; x < 9; ++x)
                {
                    char c = a[y][x];
                    if (c >= '1' && c <= '9')
                    {
                        values[x, y] = c - '1';
                        flags[x, y] = CellFlags.Fixed;
                    }
                }
            ResetSolver();
            return true;
        }

        public bool SetGridStrings9x9Jigsaw(string[] a)
        {
            bool diags = false;
            List<string> l = new List<string>();
            for (int y = 0; y < a.Length; ++y)
            {
                if (a[y].ToUpper().StartsWith("DIAG"))
                    diags = true;
                else
                {
                    string s = "";
                    for (int x = 0; x < a[y].Length-1; ++x)
                    {
                        char b = a[y][x];
                        if (b >= 'a' && b <= 'i')
                        {
                            ++x;
                            char c = a[y][x];
                            if (c == '0')
                                c = '.';
                            if (c == '.' || c >= '1' && c <= '9')
                            {
                                s += b;
                                s += c;
                            }
                        }
                    }
                    if (s.Length == 18)
                        l.Add(s);
                }
            }
            a = l.ToArray();
            if (a.Length != 9)
                return false;
            diagonal = diags;
            for (int y = 0; y < 9; ++y)
                for (int x = 0; x < 9; ++x)
                {
                    char b = a[y][x * 2];
                    char c = a[y][x * 2 + 1];
                    if (c >= '1' && c <= '9')
                    {
                        values[x, y] = c - '1';
                        flags[x, y] = CellFlags.Fixed;
                    }
                    else
                    {
                        values[x, y] = -1;
                        flags[x, y] = CellFlags.Free;
                    }
                    boxes[x, y] = b - 'a';
                }
            ResetSolver();
            return true;
        }

        public void ClearEntries()
        {
            for(int x=0;x<9;++x)
                for(int y=0;y<9;++y)
                    if (FlagAt(x, y) == CellFlags.Play)
                    {
                        flags[x, y] = CellFlags.Free;
                        values[x, y] = -1;
                    }
            ResetSolver();
        }

        public void Generate(HintSelections hints)
        {
            // Take any solution for a clear grid
            ClearGrid();
            ExactCover.Tile[] soln = solver.RandomSolution();
            if (soln == null)
                return;
            int[,] ans = new int[9, 9];
            foreach (ExactCover.Tile t in soln)
            {
                int x, y, n;
                t.GetCandidateInfo(out x, out y, out n);
                ans[x, y] = n;
            }
            // Add clues until soluable
            PlayMode = PlayModes.Edit;
            while (true)
            {
                ExactCover.SolveResult sr = solver.DoLogicalSolve(this, hints);
                if (sr == ExactCover.SolveResult.SingleSolution)
                    break;
                int x = Utils.Rnd(9);
                int y = Utils.Rnd(9);
                if (sr == ExactCover.SolveResult.NoSolutions)
                {
                    ClearCell(x, y);
                    ClearCell(8 - x, 8 - y);
                }
                else
                {
                    SetCell(x, y, ans[x, y]);
                    SetCell(8 - x, 8 - y, ans[8 - x, 8 - y]);
                }
            }
            // Remove any clues where it remains soluable
            for (int x = 0; x < 9; ++x)
                for (int y = 0; y < 9; ++y)
                {
                    ClearCell(x, y);
                    if (solver.DoLogicalSolve(this, hints) != ExactCover.SolveResult.SingleSolution)
                        SetCell(x, y, ans[x, y]);
                }
            ResetSolver();
        }

    }
}
